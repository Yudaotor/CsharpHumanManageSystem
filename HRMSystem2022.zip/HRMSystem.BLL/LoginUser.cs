﻿using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.BLL
{
    public class LoginUser
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsDeleted { get; set; }
        public string RealName { get; set; }
        public bool IsLocked { get; set; }

        private static LoginUser lu = null;
        private LoginUser()
        {

        }
        public static LoginUser GetInstance()
        {
            if(lu == null)
            {
                lu = new LoginUser();
            }
            return lu;
        }
        public void InitMember(string un)
        {
            OperatorService opSev = new OperatorService();
            Operator op = opSev.GetOperator(un);
            if(op != null)
            {
                lu.Id = op.Id;
                lu.RealName = op.RealName;
                lu.Password = op.Password;
                lu.UserName = op.UserName;
                lu.IsDeleted = op.IsDeleted;
                lu.IsLocked = op.IsLocked;
            }
        }
    }
}
