﻿using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.BLL
{
    public class SystemGuard
    {
        public UserType check(string un, string pwd)
        {
            OperatorService opSev = new OperatorService();
            Operator op = opSev.GetOperator(un);
            if (op == null) return UserType.noUser;
            else if (op.Password != pwd) return UserType.pwdError;
            else if (op.UserName == "admin") return UserType.admin;
            else if (op.IsLocked) return UserType.locked;
            else if (op.IsDeleted) return UserType.deleted;
            else return UserType.validUser;

        }
        public enum UserType { validUser, pwdError, noUser, locked, deleted, admin};
    }

}
