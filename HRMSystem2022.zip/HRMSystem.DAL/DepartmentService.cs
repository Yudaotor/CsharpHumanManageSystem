﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class DepartmentService
    {
        public bool InsertDepartment(string name)
        {
            string sql = "INSERT INTO Department(Id, Name) VALUES(NEWID(), @Name)";
            SqlParameter paramName = new SqlParameter("@Name", name);
            int n = SqlHelper.ExecuteNonQuery(sql, paramName);
            return n > 0;
        }
        public bool deleteDepartment(string name)
        {
            string sql = "delete from Department where Name = @Name";
            SqlParameter paramName = new SqlParameter("@Name", name);
            int n = SqlHelper.ExecuteNonQuery(sql, paramName);
            return n > 0;
        }
        public DataTable GetDeptList()
        {
            string sql = "select Id as 编号, Name as 部门名 from Department";
            return SqlHelper.GetDataTable(sql);
        }

    }
}
