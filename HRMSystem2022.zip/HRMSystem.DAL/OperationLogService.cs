﻿using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class OperationLogService
    {
        public bool LogAdd(OperationLog ol)
        {
            string sql = "insert into OperationLog values(@Id, @OperatorId, @ActionDate, @ActionDesc)";
            SqlParameter[] Parameters = {
                new SqlParameter("@Id", ol.Id),
                new SqlParameter("@OperatorId", ol.OperatorId),
                new SqlParameter("@ActionDate", ol.ActionDate),
                new SqlParameter("@ActionDesc", ol.ActionDesc)
            };
            int n = SqlHelper.ExecuteNonQuery(sql, Parameters);
            return n > 0;
        }
        public int GetLogCount()
        {
            string sql = "select count(*) from OperationLog";
            int n = SqlHelper.ExecuteNonQuery(sql);
            return n;
        }
        public DataTable GetLogList(int pageNo, int numPerPage)
        {
            string sql = "SELECT Temp.Id AS 编号,Operator.RealName AS 操作员, Temp.ActionDate AS 操作时间, Temp.ActionDesc AS 描述 FROM (SELECT TOP(@LogNum) * FROM OperationLog WHERE Id NOT IN(SELECT TOP(@BeforeNum) Id FROM OperationLog)) AS Temp, Operator WHERE Temp.OperatorId = Operator.Id";
            SqlParameter[] parameters = {
                    new SqlParameter("@LogNum", numPerPage),
                    new SqlParameter("@BeforeNum", numPerPage * (pageNo - 1))
                };
            return SqlHelper.GetDataTable(sql, parameters);
        }
    }
}
