﻿using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class OperatorService
    {
        public Operator GetOperator(string un)
        {
            Operator op = null;
            string sql = "select * from Operator where UserName = @UserName";
            SqlParameter paramUserName = new SqlParameter("@UserName", un);
            SqlDataReader sdr = SqlHelper.ExecuteReader(sql, paramUserName);
            if (sdr.Read())
                {
                    op = new Operator();
                    op.Id = (Guid)sdr["Id"];
                    op.UserName = sdr["UserName"].ToString();
                    op.Password = sdr["Password"].ToString();
                    op.IsDeleted = (bool)sdr["IsDeleted"];
                    op.RealName = sdr["RealName"].ToString();
                    op.IsLocked = (bool)sdr["IsLocked"];
                }
            sdr.Close();
            return op;
        }
        public void PwdModify(string un, string pwdAfter)
        {
            string sql = "update Operator set Password = @PasswordAfter where UserName = @UserName";
            SqlParameter[] parames = {
                new SqlParameter("@PasswordAfter", pwdAfter),
                new SqlParameter("@UserName", un)
            };
            int n = SqlHelper.ExecuteNonQuery(sql, parames);
        }

        public bool InsertOperator(string RealName, string Password, string UserName)
        {
            string sql = "INSERT INTO Operator(Id, UserName, Password, IsDeleted, RealName, IsLocked) VALUES(NEWID(), @UserName, @Password, 0, @RealName, 0)";
            SqlParameter[] parames = {
                new SqlParameter("@UserName", UserName),
                new SqlParameter("@Password", Password),
                new SqlParameter("@RealName", RealName)
            };
            int n = SqlHelper.ExecuteNonQuery(sql, parames);
            return n > 0;
        }

        public bool DeleteOperator(string UserName)
        {
            string sql = "UPDATE Operator SET IsDeleted = 1 WHERE @UserName = UserName";
            SqlParameter paramUserName = new SqlParameter("@UserName", UserName);
            int n = SqlHelper.ExecuteNonQuery(sql, paramUserName);
            return n > 0;
        }
        public bool LockOperator(string UserName)
        {
            string sql = "UPDATE Operator SET IsLocked = 1 WHERE @UserName = UserName";
            SqlParameter paramUserName = new SqlParameter("@UserName", UserName);
            int n = SqlHelper.ExecuteNonQuery(sql, paramUserName);
            return n > 0;
        }
    }
}
