﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.Modole
{
    public class EmployeeSelect
    {
        public string Name { get; set; }
        public DateTime InDay1 { get; set; }
        public DateTime InDay2 { get; set; }
        public Guid DepartmentId { get; set; }
        public bool TimeCheck { get; set; }
    }
}
