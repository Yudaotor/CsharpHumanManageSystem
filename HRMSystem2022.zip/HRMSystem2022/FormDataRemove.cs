﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormDataRemove : Form
    {
        public FormDataRemove()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime datetime = dtp1.Value;
            string sql1 = "insert into dbo.NewOperationLog(Id, OperatorId, ActionDate, ActionDesc)(select Id, OperatorId, ActionDate, ActionDesc from dbo.OperationLog where ActionDate <= @date)";
            string sql2 = "delete from dbo.OperationLog where ActionDate <= @date";
            SqlParameter parameters = new SqlParameter("@date", datetime);
            if(SqlHelper.Execute(sql1, sql2, parameters))
            {
                CommonHelper.ShowSuccMessageBox("迁移成功!");
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("迁移失败!");
            }
        }
    }
}
