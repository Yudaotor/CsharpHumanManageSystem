﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormDeptDelete : Form
    {
        public FormDeptDelete()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            DepartmentService deptSev = new DepartmentService();
            if (deptSev.deleteDepartment(textBoxNameAdd.Text))
            {
                CommonHelper.ShowSuccMessageBox("删除成功!");
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("未找到该部门,删除失败!");
            }
        }
    }
}
