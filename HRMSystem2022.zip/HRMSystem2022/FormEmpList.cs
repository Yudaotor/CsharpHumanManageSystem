﻿using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormEmpList : Form
    {
        public FormEmpList()
        {
            InitializeComponent();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            EmployeeService es = new EmployeeService();
            EmployeeSelect emp = new EmployeeSelect();
            if (checkBoxName.Checked)
            {
                if(textBoxName.Text == "")
                {
                    CommonHelper.ShowErrorMessageBox("请输入姓名！");
                }
                else
                {
                    emp.Name = textBoxName.Text;
                }
            }
            if (checkBoxDept.Checked)
            {
                if (comboBox1.SelectedIndex == -1)
                {
                    CommonHelper.ShowErrorMessageBox("请选择部门！");
                }
                else
                {
                    emp.DepartmentId = (Guid)comboBox1.SelectedValue;
                }
            }
            if (checkBoxTime.Checked)
            {
                emp.TimeCheck = true;
                emp.InDay1 = dateTimePicker1.Value;
                emp.InDay2 = dateTimePicker2.Value;
            }
            dataGridView1.DataSource = es.GetEmployeeList(emp);
        }

        private void FormEmpList_Load(object sender, EventArgs e)
        {
            EmployeeService es = new EmployeeService();
            DepartmentService ds = new DepartmentService();
            dataGridView1.DataSource = es.GetEmployeeList();
            comboBox1.ValueMember = "编号";
            comboBox1.DisplayMember = "部门名";
            comboBox1.DataSource = ds.GetDeptList();
            comboBox1.SelectedIndex = -1;
        }

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            Form fmEmpAdd = new FormEmployeeAdd();
            DialogResult dr = fmEmpAdd.ShowDialog();
            if(dr == DialogResult.OK)
            {
                EmployeeService es = new EmployeeService();
                CommonHelper.ShowSuccMessageBox("保存成功！");
                dataGridView1.DataSource = es.GetEmployeeList();
            }
            else if(dr == DialogResult.Cancel)
            {
                CommonHelper.ShowErrorMessageBox("取消保存！");
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("保存失败！");
            }
        }

        private void tsbEdit_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                string id = "";
                id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                if(string.IsNullOrEmpty(id))
                {
                    CommonHelper.ShowErrorMessageBox("请先选中员工！");
                }
                else
                {
                    Guid empid = Guid.Parse(id);
                    Form fmEmpAdd = new FormEmployeeAdd(empid);
                    DialogResult dr = fmEmpAdd.ShowDialog();
                    EmployeeService es = new EmployeeService();
                    dataGridView1.DataSource = es.GetEmployeeList();
                    if(dr == DialogResult.OK)
                    {
                        CommonHelper.ShowSuccMessageBox("修改成功!");
                    }
                    else 
                    {
                        CommonHelper.ShowErrorMessageBox("取消修改!");
                    }
                }
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("请选中行！");
            }
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                if (string.IsNullOrEmpty(id))
                {
                    CommonHelper.ShowErrorMessageBox("请先选中员工！");
                }
                else
                {
                    Guid empid = Guid.Parse(id);
                    EmployeeService es = new EmployeeService();
                    if (es.deleteEmployeeById(empid))
                    {
                        CommonHelper.ShowSuccMessageBox("删除成功!");
                    }
                    else
                    {
                        CommonHelper.ShowErrorMessageBox("删除失败!");
                    }
                    dataGridView1.DataSource = es.GetEmployeeList();
                }
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("请选中行！");
            }
        }

        private void tsbExport_Click(object sender, EventArgs e)
        {
            ExcelService es = new ExcelService();
            string path = "";
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "保存文件";
            sfd.Filter = "Excel 文件(*.xls)|*.xls|Excel 文件(*.xlsx)|*.xlsx|所有文件(*.*)|*.*";
            sfd.FileName = "员工信息.xls";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                path = sfd.FileName;
            }
            else
            {
                return;
            }
            if (es.CreateExcel(path))
            {
                CommonHelper.ShowSuccMessageBox("导出成功!");
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("导出失败!");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
