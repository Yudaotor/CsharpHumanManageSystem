﻿using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormEmployeeAdd : Form
    {
        Guid empid = Guid.Empty;
        Employee emp = new Employee();
        public FormEmployeeAdd()
        {
            InitializeComponent();
        }
        public FormEmployeeAdd(Guid a)
        {
            InitializeComponent();
            empid = a;
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入姓名!");
                return;
            }
            else
            {
                emp.Name = textBoxName.Text;
            }
            if (textBoxNation.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入民族!");
                return;
            }
            else
            {
                emp.Nation = textBoxNation.Text;
            }
            if (textBoxEmail.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入电子邮箱!");
                return;
            }
            else
            {
                emp.Email = textBoxEmail.Text;
            }
            if (textBoxHomeTown.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入籍贯!");
                return;
            }
            else
            {
                emp.NativePlace = textBoxHomeTown.Text;
            }
            if (textBoxNumber.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入工号!");
                return;
            }
            else
            {
                emp.Number = textBoxNumber.Text;
            }
            if (textBoxPlace.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入联系地址!");
                return;
            }
            else
            {
                emp.Address = textBoxPlace.Text;
            }
            if (textBoxTelephone.Text == "")
            {
                CommonHelper.ShowErrorMessageBox("请输入联系电话!");
                return;
            }
            else
            {
                emp.Telephone = textBoxTelephone.Text;
            }
            if (richTextBoxRemark.Text == "")
            {
                emp.Remarks = "";
            }
            else
            {
                emp.Remarks = richTextBoxRemark.Text;
            }
            if (richTextBoxResume.Text == "")
            {
                emp.Resume = "";
            }
            else
            {
                emp.Resume = richTextBoxResume.Text;
            }
            emp.GenderId = (Guid)comboBoxGender.SelectedValue;
            emp.MarriageId = (Guid)comboBoxMarrage.SelectedValue;
            emp.PartyId = (Guid)comboBoxZhengZhi.SelectedValue;
            emp.EducationId = (Guid)comboBoxStudy.SelectedValue;
            emp.DepartmentId = (Guid)comboBoxDept.SelectedValue;
            emp.BirthDay = dateTimePickerBirth.Value;
            emp.InDay = dateTimePickerInDay.Value;
            emp.Id = Guid.NewGuid();
            if(emp.Photo == null){
                CommonHelper.ShowErrorMessageBox("请选择照片!");
                return;
            }
            EmployeeService es = new EmployeeService();
            if (empid == Guid.Empty)
            {
                if (es.InsertEmployee(emp))
                {
                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    CommonHelper.ShowErrorMessageBox("保存失败!");
                }

            }
            else
            {
                if (es.updateEmployee(emp, empid))
                {
                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    CommonHelper.ShowErrorMessageBox("修改失败!");
                }
            }
            

        }

        private void FormEmployeeAdd_Load(object sender, EventArgs e)
        {
            DictionaryService ds = new DictionaryService();
            comboBoxGender.DisplayMember = "Name";
            comboBoxGender.ValueMember = "Id";    
            comboBoxGender.DataSource = ds.GetComboList("性别");
            comboBoxGender.SelectedIndex = -1;
            comboBoxMarrage.DisplayMember = "Name";
            comboBoxMarrage.ValueMember = "Id";
            comboBoxMarrage.DataSource = ds.GetComboList("婚姻状况");
            comboBoxMarrage.SelectedIndex = -1;
            comboBoxZhengZhi.DisplayMember = "Name";
            comboBoxZhengZhi.ValueMember = "Id";
            comboBoxZhengZhi.DataSource = ds.GetComboList("政治面貌");
            comboBoxZhengZhi.SelectedIndex = -1;
            comboBoxStudy.DisplayMember = "Name";
            comboBoxStudy.ValueMember = "Id";
            comboBoxStudy.DataSource = ds.GetComboList("学历");
            comboBoxStudy.SelectedIndex = -1;
            DepartmentService deptSer = new DepartmentService();
            comboBoxDept.ValueMember = "编号";
            comboBoxDept.DisplayMember = "部门名";
            comboBoxDept.DataSource = deptSer.GetDeptList();
            comboBoxDept.SelectedIndex = -1;
            if(empid != Guid.Empty)
            {
                EmployeeService es = new EmployeeService();
                emp = es.GetEmpById(empid);
                textBoxName.Text = emp.Name;
                textBoxNation.Text = emp.Nation;
                textBoxNumber.Text = emp.Number;
                textBoxPlace.Text = emp.Address;
                textBoxHomeTown.Text = emp.NativePlace;
                textBoxEmail.Text = emp.Email;
                textBoxTelephone.Text = emp.Telephone;
                richTextBoxResume.Text = emp.Resume;
                richTextBoxRemark.Text = emp.Remarks;
                comboBoxDept.SelectedValue = emp.DepartmentId;
                comboBoxGender.SelectedValue = emp.GenderId;
                comboBoxMarrage.SelectedValue = emp.MarriageId;
                comboBoxZhengZhi.SelectedValue = emp.PartyId;
                comboBoxStudy.SelectedValue = emp.EducationId;
                MemoryStream ms = new MemoryStream(emp.Photo);
                pictureBox1.Image = new Bitmap(ms);
            }
        }

        private void tabPageBaseInfo_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "JPG图片|*.jpg|BMP图片|*.bmp|Gif图片|*.gif";
                ofd.ShowDialog();
                pictureBox1.Image = Image.FromFile(ofd.FileName);
                FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
                emp.Photo = new byte[fs.Length];
                fs.Read(emp.Photo, 0, Convert.ToInt32(fs.Length));
            }catch(Exception ex)
            {
                CommonHelper.ShowErrorMessageBox("请选择图片");
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
