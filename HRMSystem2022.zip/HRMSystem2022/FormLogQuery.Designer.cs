﻿namespace HRMSystem2022
{
    partial class FormLogQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblPageTotal = new System.Windows.Forms.Label();
            this.lblPageCurrent = new System.Windows.Forms.Label();
            this.llblFirst = new System.Windows.Forms.LinkLabel();
            this.llblPrev = new System.Windows.Forms.LinkLabel();
            this.llblNext = new System.Windows.Forms.LinkLabel();
            this.llblLast = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 14);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(611, 314);
            this.dataGridView1.TabIndex = 0;
            // 
            // lblPageTotal
            // 
            this.lblPageTotal.AutoSize = true;
            this.lblPageTotal.Location = new System.Drawing.Point(35, 356);
            this.lblPageTotal.Name = "lblPageTotal";
            this.lblPageTotal.Size = new System.Drawing.Size(47, 12);
            this.lblPageTotal.TabIndex = 1;
            this.lblPageTotal.Text = "共{0}页";
            // 
            // lblPageCurrent
            // 
            this.lblPageCurrent.AutoSize = true;
            this.lblPageCurrent.Location = new System.Drawing.Point(115, 356);
            this.lblPageCurrent.Name = "lblPageCurrent";
            this.lblPageCurrent.Size = new System.Drawing.Size(47, 12);
            this.lblPageCurrent.TabIndex = 2;
            this.lblPageCurrent.Text = "第{0}页";
            // 
            // llblFirst
            // 
            this.llblFirst.AutoSize = true;
            this.llblFirst.Location = new System.Drawing.Point(331, 356);
            this.llblFirst.Name = "llblFirst";
            this.llblFirst.Size = new System.Drawing.Size(29, 12);
            this.llblFirst.TabIndex = 3;
            this.llblFirst.TabStop = true;
            this.llblFirst.Text = "首页";
            this.llblFirst.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblFirst_LinkClicked);
            // 
            // llblPrev
            // 
            this.llblPrev.AutoSize = true;
            this.llblPrev.Location = new System.Drawing.Point(520, 356);
            this.llblPrev.Name = "llblPrev";
            this.llblPrev.Size = new System.Drawing.Size(41, 12);
            this.llblPrev.TabIndex = 4;
            this.llblPrev.TabStop = true;
            this.llblPrev.Text = "上一页";
            this.llblPrev.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblPrev_LinkClicked);
            // 
            // llblNext
            // 
            this.llblNext.AutoSize = true;
            this.llblNext.Location = new System.Drawing.Point(451, 356);
            this.llblNext.Name = "llblNext";
            this.llblNext.Size = new System.Drawing.Size(41, 12);
            this.llblNext.TabIndex = 5;
            this.llblNext.TabStop = true;
            this.llblNext.Text = "下一页";
            this.llblNext.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblNext_LinkClicked);
            // 
            // llblLast
            // 
            this.llblLast.AutoSize = true;
            this.llblLast.Location = new System.Drawing.Point(393, 356);
            this.llblLast.Name = "llblLast";
            this.llblLast.Size = new System.Drawing.Size(29, 12);
            this.llblLast.TabIndex = 6;
            this.llblLast.TabStop = true;
            this.llblLast.Text = "尾页";
            this.llblLast.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblLast_LinkClicked);
            // 
            // FormLogQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 386);
            this.Controls.Add(this.llblLast);
            this.Controls.Add(this.llblNext);
            this.Controls.Add(this.llblPrev);
            this.Controls.Add(this.llblFirst);
            this.Controls.Add(this.lblPageCurrent);
            this.Controls.Add(this.lblPageTotal);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormLogQuery";
            this.Text = "日志查询";
            this.Load += new System.EventHandler(this.FormLogQuery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblPageTotal;
        private System.Windows.Forms.Label lblPageCurrent;
        private System.Windows.Forms.LinkLabel llblFirst;
        private System.Windows.Forms.LinkLabel llblPrev;
        private System.Windows.Forms.LinkLabel llblNext;
        private System.Windows.Forms.LinkLabel llblLast;
    }
}