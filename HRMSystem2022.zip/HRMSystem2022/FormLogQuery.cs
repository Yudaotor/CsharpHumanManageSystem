﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormLogQuery : Form
    {
        public static int NUM_PER_PAGE = 13;
        public int currentPage = 1;
        public OperationLogService logServ = null;
        public int pages = 0;
        public FormLogQuery()
        {
            logServ = new OperationLogService();
            InitializeComponent();
        }
        private void show(int pageNo)
        {
            dataGridView1.DataSource = logServ.GetLogList(pageNo, NUM_PER_PAGE);
            lblPageCurrent.Text = string.Format("第{0}页", pageNo);
        }
        private void FormLogQuery_Load(object sender, EventArgs e)
        {
            lblPageCurrent.Text = string.Format("第{0}页", currentPage);
            int n = logServ.GetLogCount();
            pages = n % NUM_PER_PAGE == 0 ? n / NUM_PER_PAGE : n / NUM_PER_PAGE + 1;
            lblPageTotal.Text = string.Format("共{0}页", pages);
            dataGridView1.DataSource = logServ.GetLogList(currentPage, NUM_PER_PAGE);
            llblPrev.Enabled = false;
        }

        private void llblFirst_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (currentPage != 1)
            {
                llblNext.Enabled = true;
            }
            currentPage = 1;
            show(currentPage);
            llblPrev.Enabled = false;
        }

        private void llblLast_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (currentPage != 1)
            {
                llblPrev.Enabled = true;
            }
            llblPrev.Enabled = true;
            currentPage = pages;
            show(currentPage);
            llblNext.Enabled = false;
        }

        private void llblNext_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            llblPrev.Enabled = true;
            currentPage++;
            show(currentPage);
            if (currentPage == pages)
            {
                llblNext.Enabled = false;
            }
        }

        private void llblPrev_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        { 
            llblNext.Enabled = true;
            currentPage--;
            show(currentPage);
            if (currentPage == 1)
            {
                llblPrev.Enabled = false;
            }
        }
    }
}
