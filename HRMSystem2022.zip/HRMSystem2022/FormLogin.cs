﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using HRMSystem.DAL;
using HRMSystem.Modole;
using HRMSystem.BLL;
using static HRMSystem.BLL.SystemGuard;

namespace HRMSystem2022
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            OperationLog ol = new OperationLog();
            ol.ActionDate = DateTime.Now;
            ol.Id = Guid.NewGuid(); 
            SystemGuard sg = new SystemGuard();
            UserType ut = sg.check(textBoxUserName.Text, CommonHelper.GetMd5(textBoxPassword.Text));
            if (ut == UserType.noUser)
            {
                ol.ActionDesc = "登录用户名不存在！";
                ol.OperatorId = Guid.Empty;
                CommonHelper.ShowErrorMessageBox("用户名错误！");
                this.DialogResult = DialogResult.Cancel;
            }
            else if (ut == UserType.pwdError)
            {
                ol.ActionDesc = string.Format("用户{0}尝试使用错误密码{1}登录失败", textBoxUserName.Text, textBoxPassword.Text);
                ol.OperatorId = Guid.Empty;
                CommonHelper.ShowErrorMessageBox("密码错误");
                this.DialogResult = DialogResult.Cancel;
            }
            else if (ut == UserType.deleted)
            {
                LoginUser lu = LoginUser.GetInstance();
                lu.InitMember(textBoxUserName.Text);
                ol.ActionDesc = "用户登录成功！";
                ol.OperatorId = lu.Id;
                CommonHelper.ShowErrorMessageBox("该用户已注销!");
                this.DialogResult = DialogResult.Cancel;
            }
            else if (ut == UserType.locked)
            {
                LoginUser lu = LoginUser.GetInstance();
                lu.InitMember(textBoxUserName.Text);
                ol.ActionDesc = "用户登录成功！";
                ol.OperatorId = lu.Id;
                CommonHelper.ShowErrorMessageBox("该用户已被冻结!");
                this.DialogResult = DialogResult.Cancel;
            }
            else if (ut == UserType.admin)
            {
                LoginUser lu = LoginUser.GetInstance();
                lu.InitMember(textBoxUserName.Text);
                ol.ActionDesc = "管理员登录成功！";
                ol.OperatorId = lu.Id;
                CommonHelper.ShowSuccMessageBox("管理员，欢迎进入本系统！");
                
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                LoginUser lu = LoginUser.GetInstance();
                lu.InitMember(textBoxUserName.Text);
                ol.ActionDesc = "用户登录成功！";
                ol.OperatorId = lu.Id;
                CommonHelper.ShowSuccMessageBox("欢迎进入本系统！");
                this.DialogResult = DialogResult.OK;
            }
            OperationLogService logServ = new OperationLogService();
            logServ.LogAdd(ol);
        }

        private void buttonCancle_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
