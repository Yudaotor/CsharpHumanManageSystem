﻿namespace HRMSystem2022
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslUserInfo = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.adminOperate = new System.Windows.Forms.ToolStripMenuItem();
            this.UserManage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteUser = new System.Windows.Forms.ToolStripMenuItem();
            this.lockUser = new System.Windows.Forms.ToolStripMenuItem();
            this.queryUser = new System.Windows.Forms.ToolStripMenuItem();
            this.部门管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddDept = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteDept = new System.Windows.Forms.ToolStripMenuItem();
            this.showAllDept = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLogQuery = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.meMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.pwdChangeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiEmployee = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSalarySheet = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSalarySheetBuild = new System.Windows.Forms.ToolStripMenuItem();
            this.打印工资单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslUserInfo,
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 680);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1344, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslUserInfo
            // 
            this.tsslUserInfo.Name = "tsslUserInfo";
            this.tsslUserInfo.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminOperate,
            this.tsmiEmployee,
            this.tsmiSalarySheet,
            this.meMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1344, 28);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // adminOperate
            // 
            this.adminOperate.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UserManage,
            this.部门管理ToolStripMenuItem,
            this.tsmiLogQuery,
            this.tsmiRemove});
            this.adminOperate.Name = "adminOperate";
            this.adminOperate.Size = new System.Drawing.Size(96, 24);
            this.adminOperate.Text = "管理员操作";
            this.adminOperate.Click += new System.EventHandler(this.adminOperate_Click);
            // 
            // UserManage
            // 
            this.UserManage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.deleteUser,
            this.lockUser,
            this.queryUser});
            this.UserManage.Name = "UserManage";
            this.UserManage.Size = new System.Drawing.Size(181, 26);
            this.UserManage.Text = "用户管理";
            this.UserManage.Click += new System.EventHandler(this.UserManage_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(181, 26);
            this.toolStripMenuItem1.Text = "添加用户";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItemAdd_Click);
            // 
            // deleteUser
            // 
            this.deleteUser.Name = "deleteUser";
            this.deleteUser.Size = new System.Drawing.Size(181, 26);
            this.deleteUser.Text = "删除用户";
            this.deleteUser.Click += new System.EventHandler(this.deleteUser_Click);
            // 
            // lockUser
            // 
            this.lockUser.Name = "lockUser";
            this.lockUser.Size = new System.Drawing.Size(181, 26);
            this.lockUser.Text = "锁定用户";
            this.lockUser.Click += new System.EventHandler(this.lockUser_Click);
            // 
            // queryUser
            // 
            this.queryUser.Name = "queryUser";
            this.queryUser.Size = new System.Drawing.Size(181, 26);
            this.queryUser.Text = "查询用户";
            this.queryUser.Click += new System.EventHandler(this.queryUser_Click);
            // 
            // 部门管理ToolStripMenuItem
            // 
            this.部门管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddDept,
            this.deleteDept,
            this.showAllDept});
            this.部门管理ToolStripMenuItem.Name = "部门管理ToolStripMenuItem";
            this.部门管理ToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.部门管理ToolStripMenuItem.Text = "部门管理";
            this.部门管理ToolStripMenuItem.Click += new System.EventHandler(this.部门管理ToolStripMenuItem_Click);
            // 
            // AddDept
            // 
            this.AddDept.Name = "AddDept";
            this.AddDept.Size = new System.Drawing.Size(181, 26);
            this.AddDept.Text = "添加部门";
            this.AddDept.Click += new System.EventHandler(this.AddDept_Click);
            // 
            // deleteDept
            // 
            this.deleteDept.Name = "deleteDept";
            this.deleteDept.Size = new System.Drawing.Size(181, 26);
            this.deleteDept.Text = "删除部门";
            this.deleteDept.Click += new System.EventHandler(this.deleteDept_Click);
            // 
            // showAllDept
            // 
            this.showAllDept.Name = "showAllDept";
            this.showAllDept.Size = new System.Drawing.Size(181, 26);
            this.showAllDept.Text = "全部部门";
            this.showAllDept.Click += new System.EventHandler(this.showAllDept_Click);
            // 
            // tsmiLogQuery
            // 
            this.tsmiLogQuery.Name = "tsmiLogQuery";
            this.tsmiLogQuery.Size = new System.Drawing.Size(181, 26);
            this.tsmiLogQuery.Text = "日志查询";
            this.tsmiLogQuery.Click += new System.EventHandler(this.tsmiLogQuery_Click);
            // 
            // tsmiRemove
            // 
            this.tsmiRemove.Name = "tsmiRemove";
            this.tsmiRemove.Size = new System.Drawing.Size(181, 26);
            this.tsmiRemove.Text = "日志迁移";
            this.tsmiRemove.Click += new System.EventHandler(this.tsmiRemove_Click);
            // 
            // meMenu
            // 
            this.meMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pwdChangeMenu});
            this.meMenu.Name = "meMenu";
            this.meMenu.Size = new System.Drawing.Size(51, 24);
            this.meMenu.Text = "我的";
            // 
            // pwdChangeMenu
            // 
            this.pwdChangeMenu.Name = "pwdChangeMenu";
            this.pwdChangeMenu.Size = new System.Drawing.Size(181, 26);
            this.pwdChangeMenu.Text = "修改密码";
            this.pwdChangeMenu.Click += new System.EventHandler(this.pwdChangeMenu_Click);
            // 
            // tsmiEmployee
            // 
            this.tsmiEmployee.Name = "tsmiEmployee";
            this.tsmiEmployee.Size = new System.Drawing.Size(81, 24);
            this.tsmiEmployee.Text = "员工列表";
            this.tsmiEmployee.Click += new System.EventHandler(this.tsmiEmployee_Click);
            // 
            // tsmiSalarySheet
            // 
            this.tsmiSalarySheet.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiSalarySheetBuild,
            this.打印工资单ToolStripMenuItem});
            this.tsmiSalarySheet.Name = "tsmiSalarySheet";
            this.tsmiSalarySheet.Size = new System.Drawing.Size(96, 24);
            this.tsmiSalarySheet.Text = "工资单管理";
            // 
            // tsmiSalarySheetBuild
            // 
            this.tsmiSalarySheetBuild.Name = "tsmiSalarySheetBuild";
            this.tsmiSalarySheetBuild.Size = new System.Drawing.Size(181, 26);
            this.tsmiSalarySheetBuild.Text = "工资单生成";
            this.tsmiSalarySheetBuild.Click += new System.EventHandler(this.tsmiSalarySheetBuild_Click);
            // 
            // 打印工资单ToolStripMenuItem
            // 
            this.打印工资单ToolStripMenuItem.Name = "打印工资单ToolStripMenuItem";
            this.打印工资单ToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.打印工资单ToolStripMenuItem.Text = "打印工资单";
            this.打印工资单ToolStripMenuItem.Click += new System.EventHandler(this.打印工资单ToolStripMenuItem_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 702);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.Text = "人力资源管理系统";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslUserInfo;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem adminOperate;
        private System.Windows.Forms.ToolStripMenuItem meMenu;
        private System.Windows.Forms.ToolStripMenuItem pwdChangeMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmiLogQuery;
        private System.Windows.Forms.ToolStripMenuItem 部门管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem UserManage;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteUser;
        private System.Windows.Forms.ToolStripMenuItem lockUser;
        private System.Windows.Forms.ToolStripMenuItem queryUser;
        private System.Windows.Forms.ToolStripMenuItem AddDept;
        private System.Windows.Forms.ToolStripMenuItem deleteDept;
        private System.Windows.Forms.ToolStripMenuItem showAllDept;
        private System.Windows.Forms.ToolStripMenuItem tsmiRemove;
        private System.Windows.Forms.ToolStripMenuItem tsmiEmployee;
        private System.Windows.Forms.ToolStripMenuItem tsmiSalarySheet;
        private System.Windows.Forms.ToolStripMenuItem tsmiSalarySheetBuild;
        private System.Windows.Forms.ToolStripMenuItem 打印工资单ToolStripMenuItem;
    }
}