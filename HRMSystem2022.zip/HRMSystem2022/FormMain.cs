﻿using HRMSystem.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    
    public partial class FormMain : Form
    {
        
        public FormMain()
        {
            InitializeComponent();
        }
        private void FormMain_Load(object sender, EventArgs e)
        {
            Form fmLogin = new FormLogin();
            DialogResult dr = fmLogin.ShowDialog();
            LoginUser lu = LoginUser.GetInstance();
            
            if(lu.UserName != "admin")
            {
                tsslUserInfo.Text = string.Format("尊敬的用户{0},欢迎您进入本系统！登录时间为{1}", lu.RealName, DateTime.Now.ToString());
                adminOperate.Enabled = false;
            }
            else
            {
                tsslUserInfo.Text = string.Format("尊敬的管理员{0},欢迎您进入本系统！登录时间为{1}", lu.RealName, DateTime.Now.ToString());
            }
            if(dr == DialogResult.Cancel)
            {
                Application.Exit();
            }  
        }

        private void addMenu_Click(object sender, EventArgs e)
        {
            Form fmAdd = new FormUserAdd();
            fmAdd.MdiParent = this;
            fmAdd.Show();
        }

        private void searchMenu_Click(object sender, EventArgs e)
        {
            Form fmSearch = new FormUserQuery();
            fmSearch.MdiParent = this;
            fmSearch.Show();
        }

        private void deleteMenu_Click(object sender, EventArgs e)
        {
            Form fmDelete = new FormUserDelete();
            fmDelete.MdiParent = this;
            fmDelete.Show();
        }

        private void lockMenu_Click(object sender, EventArgs e)
        {
            Form fmLock = new FormUserLock();
            fmLock.MdiParent = this;
            fmLock.Show();
        }

        private void pwdChangeMenu_Click(object sender, EventArgs e)
        {
            Form fmPwdChange = new FormUserPwdChange();
            fmPwdChange.MdiParent = this;
            fmPwdChange.Show();
        }

        private void tsmiLogQuery_Click(object sender, EventArgs e)
        {
            Form formLogQuery = new FormLogQuery();
            formLogQuery.MdiParent = this;
            formLogQuery.Show();
        }

        private void toolStripMenuItemAdd_Click(object sender, EventArgs e)
        {
            Form fmAdd = new FormUserAdd();
            fmAdd.MdiParent = this;
            fmAdd.Show();
        }

        private void deleteUser_Click(object sender, EventArgs e)
        {
            Form fmDelete = new FormUserDelete();
            fmDelete.MdiParent = this;
            fmDelete.Show();
        }

        private void UserManage_Click(object sender, EventArgs e)
        {

        }

        private void lockUser_Click(object sender, EventArgs e)
        {
            Form fmLock = new FormUserLock();
            fmLock.MdiParent = this;
            fmLock.Show();
        }

        private void queryUser_Click(object sender, EventArgs e)
        {
            Form fmSearch = new FormUserQuery();
            fmSearch.MdiParent = this;
            fmSearch.Show();
        }

        private void AddDept_Click(object sender, EventArgs e)
        {
            Form fmAdd = new FormDeptAdd();
            fmAdd.MdiParent = this;
            fmAdd.Show();
        }

        private void deleteDept_Click(object sender, EventArgs e)
        {
            Form fmDelete = new FormDeptDelete();
            fmDelete.MdiParent = this;
            fmDelete.Show();
        }

        private void showAllDept_Click(object sender, EventArgs e)
        {
            Form fmAllDept = new FormDeptShow();
            fmAllDept.MdiParent = this;
            fmAllDept.Show();
        }

        private void adminOperate_Click(object sender, EventArgs e)
        {

        }

        private void tsmiEmp_Click(object sender, EventArgs e)
        {
            Form fmEmp = new FormEmpList();
            fmEmp.MdiParent = this;
            fmEmp.Show();
        }

        private void tsmiRemove_Click(object sender, EventArgs e)
        {
            Form fmRemove = new FormDataRemove();
            fmRemove.MdiParent = this;
            fmRemove.Show();
        }

        private void 部门管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 工资单生成ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fmSalarySheet = new FormSalarySheet();
            fmSalarySheet.MdiParent = this;
            fmSalarySheet.Show();
        }

        private void tsmiPrint_Click(object sender, EventArgs e)
        {
            Form fmPrintSalarySheet = new FormPrintSalarySheet();
            fmPrintSalarySheet.MdiParent = this;
            fmPrintSalarySheet.Show();
        }

        private void tsmiEmployee_Click(object sender, EventArgs e)
        {
            Form fmEmp = new FormEmpList();
            fmEmp.MdiParent = this;
            fmEmp.Show();
        }

        private void tsmiSalarySheetBuild_Click(object sender, EventArgs e)
        {
            Form fmSalarySheet = new FormSalarySheet();
            fmSalarySheet.MdiParent = this;
            fmSalarySheet.Show();
        }

        private void 打印工资单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fmPrintSalarySheet = new FormPrintSalarySheet();
            fmPrintSalarySheet.MdiParent = this;
            fmPrintSalarySheet.Show();
        }
    }
}
