﻿using HRMSystem.BLL;
using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormSalarySheet : Form
    {
        public FormSalarySheet()
        {
            InitializeComponent();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormSalarySheet_Load(object sender, EventArgs e)
        {
            DepartmentService ds = new DepartmentService();
            comboBoxDepartment.ValueMember = "编号";
            comboBoxDepartment.DisplayMember = "部门名";
            comboBoxDepartment.DataSource = ds.GetDeptList();
            comboBoxDepartment.SelectedIndex = -1;
            DataTable months = new DataTable();
            months.Columns.Add("Mouth");
            months.Columns.Add("Value");
            for (int i = 1; i <= 12; i++)
            {
                DataRow dr = months.NewRow();
                dr["Mouth"] = i.ToString();
                dr["Value"] = i;
                months.Rows.Add(dr);
            }
            comboBoxMonth.DataSource = months;
            comboBoxMonth.DisplayMember = "Month";
            comboBoxMonth.ValueMember = "Value";
            comboBoxMonth.SelectedIndex = -1;

            DataTable years = new DataTable();
            years.Columns.Add("Year");
            years.Columns.Add("Value");
            for (int i = 2012; i <= 2032; i++)
            {
                DataRow dr = years.NewRow();
                dr["Year"] = i.ToString();
                dr["Value"] = i;
                years.Rows.Add(dr);
            }
            comboBoxYear.DataSource = years;
            comboBoxYear.DisplayMember = "Year";
            comboBoxYear.ValueMember = "Value";
            comboBoxYear.SelectedIndex = -1;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBoxMonth.SelectedIndex == -1 || comboBoxYear.SelectedIndex == -1 || comboBoxDepartment.SelectedIndex == -1)
            {
                CommonHelper.ShowErrorMessageBox("请选择正确的年份,月份和部门");
                return;
            }


            SalarySheet sheet = new SalarySheet();
            sheet.Id = Guid.NewGuid();
            sheet.Month = Convert.ToInt32(comboBoxMonth.SelectedValue);
            sheet.Year = Convert.ToInt32(comboBoxYear.SelectedValue);
            sheet.DepartmentId = (Guid)comboBoxDepartment.SelectedValue;

            EmptyJudge ej = new EmptyJudge();
            if (!ej.isEmployeeExist(sheet.DepartmentId))
            {
                CommonHelper.ShowErrorMessageBox("该部门没有员工!");
                return;
            }
            SalarySheetService sss = new SalarySheetService();
            SalarySheetItemService ssis = new SalarySheetItemService();

            
            if (!ej.isSheetExist(sheet.Month, sheet.Year, sheet.DepartmentId))
            {
                Guid sheetId = sss.BuildNewSalarySheet(sheet);
                ssis.BuildSalarySheetItems(sheetId, sheet.DepartmentId);
                dataGridView1.DataSource = ssis.GetSalarySheetItems(sheetId);
            }
            else
            {
               DialogResult dr = CommonHelper.ShowChooseMessageBox("该工资表此前已经生成过了,按'是'显示原有表数据,按'否'重新生成新表");
                if (dr == DialogResult.Yes)
                {
                    Guid sheetId = sss.GetSalarySheetId(sheet.Month, sheet.Year, sheet.DepartmentId);
                    dataGridView1.DataSource = ssis.GetSalarySheetItems(sheetId);
                }
                else if(dr == DialogResult.No)
                {
                    DialogResult drr = CommonHelper.ShowChooseMessageBox("确认是否重新生成新表?(此操作不可撤回)");
                    if (drr == DialogResult.Yes)
                    {
                        Guid sheetId = sss.GetSalarySheetId(sheet.Month, sheet.Year, sheet.DepartmentId);
                        ssis.ReBuildSalarySheetItem(sheetId);
                        dataGridView1.DataSource = ssis.GetSalarySheetItems(sss.GetSalarySheetId(sheet.Month, sheet.Year, sheet.DepartmentId));
                    }
                    else
                    {
                        Guid sheetId = sss.GetSalarySheetId(sheet.Month, sheet.Year, sheet.DepartmentId);
                        dataGridView1.DataSource = ssis.GetSalarySheetItems(sheetId);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SalarySheetItemService ssis = new SalarySheetItemService();
            SalarySheetItem item = null;
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                item = new SalarySheetItem();
                item.Id = (Guid)dataGridView1.Rows[i].Cells[0].Value;
                item.BaseSalary = (decimal)dataGridView1.Rows[i].Cells[2].Value;
                item.Bonus = (decimal)dataGridView1.Rows[i].Cells[3].Value;
                item.Fine = (decimal)dataGridView1.Rows[i].Cells[4].Value;
                item.Other = (decimal)dataGridView1.Rows[i].Cells[5].Value;
                ssis.SaveSheetItem(item);
            }
            CommonHelper.ShowSuccMessageBox("工资单保存成功!");
        }
    }
}
