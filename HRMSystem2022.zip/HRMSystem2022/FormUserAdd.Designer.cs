﻿namespace HRMSystem2022
{
    partial class FormUserAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxUserNameAdd = new System.Windows.Forms.TextBox();
            this.textBoxPasswordAdd = new System.Windows.Forms.TextBox();
            this.textBoxRealNameAdd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(122, 226);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(237, 92);
            this.buttonAdd.TabIndex = 0;
            this.buttonAdd.Text = "添加";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "用户名:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "密码:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "姓名:";
            // 
            // textBoxUserNameAdd
            // 
            this.textBoxUserNameAdd.Location = new System.Drawing.Point(143, 29);
            this.textBoxUserNameAdd.Name = "textBoxUserNameAdd";
            this.textBoxUserNameAdd.Size = new System.Drawing.Size(284, 25);
            this.textBoxUserNameAdd.TabIndex = 5;
            // 
            // textBoxPasswordAdd
            // 
            this.textBoxPasswordAdd.Location = new System.Drawing.Point(143, 98);
            this.textBoxPasswordAdd.Name = "textBoxPasswordAdd";
            this.textBoxPasswordAdd.Size = new System.Drawing.Size(284, 25);
            this.textBoxPasswordAdd.TabIndex = 6;
            // 
            // textBoxRealNameAdd
            // 
            this.textBoxRealNameAdd.Location = new System.Drawing.Point(143, 158);
            this.textBoxRealNameAdd.Name = "textBoxRealNameAdd";
            this.textBoxRealNameAdd.Size = new System.Drawing.Size(284, 25);
            this.textBoxRealNameAdd.TabIndex = 7;
            // 
            // FormAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 358);
            this.Controls.Add(this.textBoxRealNameAdd);
            this.Controls.Add(this.textBoxPasswordAdd);
            this.Controls.Add(this.textBoxUserNameAdd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormAdd";
            this.Text = "添加用户";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxUserNameAdd;
        private System.Windows.Forms.TextBox textBoxPasswordAdd;
        private System.Windows.Forms.TextBox textBoxRealNameAdd;
    }
}