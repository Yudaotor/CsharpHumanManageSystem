﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormUserAdd : Form
    {
        public FormUserAdd()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            OperatorService opSev = new OperatorService();
            if (opSev.InsertOperator(textBoxPasswordAdd.Text, CommonHelper.GetMd5(textBoxRealNameAdd.Text), textBoxUserNameAdd.Text))
            {
                CommonHelper.ShowSuccMessageBox("添加成功!");
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("添加失败!");
            }
        }
    }
}
