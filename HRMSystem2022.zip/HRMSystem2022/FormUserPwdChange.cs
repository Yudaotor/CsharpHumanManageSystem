﻿using HRMSystem.BLL;
using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormUserPwdChange : Form
    {
        public FormUserPwdChange()
        {
            InitializeComponent();
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            LoginUser lu = LoginUser.GetInstance();
            if (lu.Password.Equals(CommonHelper.GetMd5(textBoxPwdBefore.Text)))
            {
                OperatorService op = new OperatorService();
                op.PwdModify(lu.UserName, CommonHelper.GetMd5(textBoxPwdNew.Text));
                lu.Password = CommonHelper.GetMd5(textBoxPwdNew.Text);
                CommonHelper.ShowSuccMessageBox("密码修改成功!");
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("原密码输入错误!");
            }
        }
    }
}
