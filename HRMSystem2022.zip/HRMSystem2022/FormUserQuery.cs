﻿using HRMSystem.DAL;
using HRMSystem.Modole;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem2022
{
    public partial class FormUserQuery : Form
    {
        public FormUserQuery()
        {
            InitializeComponent();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            OperatorService opSev = new OperatorService();
            Operator op = opSev.GetOperator(textBoxUserName.Text);
            if (op!= null)
            {
                CommonHelper.ShowSuccMessageBox("查询成功!");
                labelUserName.Text = "用户名:" + op.UserName;
                labelId.Text = "Id:" + op.Id;
                labelIsDeleted.Text = "是否被删除:" + op.IsDeleted;
                labelIsLocked.Text = "是否被锁定:" + op.IsLocked;
                labelRealName.Text = "姓名:" + op.RealName;
                labelPassword.Text = "密码:" + op.Password;
            }
            else
            {
                CommonHelper.ShowErrorMessageBox("无此用户,查询失败!");
            }
        }

        private void textBoxUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
